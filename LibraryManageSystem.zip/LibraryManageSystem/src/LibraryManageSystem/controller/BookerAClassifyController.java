package LibraryManageSystem.controller;

        import LibraryManageSystem.mapper.BookMapper;
        import LibraryManageSystem.pojo.Book;
        import LibraryManageSystem.stage.bookadministrator.AddBook;
        import LibraryManageSystem.stage.bookadministrator.AddReader;
        import LibraryManageSystem.stage.bookadministrator.BookerMain;
        import LibraryManageSystem.stage.bookadministrator.UpdateBook;
        import LibraryManageSystem.stage.readers.ReaderMain;
        import LibraryManageSystem.utils.MybatisUtils;
        import javafx.collections.FXCollections;
        import javafx.collections.ObservableList;
        import javafx.event.ActionEvent;
        import javafx.fxml.FXML;
        import javafx.scene.Scene;
        import javafx.scene.control.Button;
        import javafx.scene.control.TableColumn;
        import javafx.scene.control.TableView;
        import javafx.scene.control.TextField;
        import javafx.scene.control.cell.PropertyValueFactory;
        import javafx.stage.Stage;
        import org.apache.ibatis.session.SqlSession;

        import java.io.IOException;
        import java.sql.Connection;
        import java.sql.DriverManager;
        import java.sql.ResultSet;
        import java.sql.Statement;

public class BookerAClassifyController {
    private String BookerID="";
    @FXML
    private TableColumn<Book, String> author;

    @FXML
    private TableView<Book> booktable;

    @FXML
    private TableColumn<Book, String> title;

    @FXML
    private TableColumn<Book, String> bookid;

    @FXML
    private Button search;

    @FXML
    private TableColumn<Book, String> publisher;

    @FXML
    private TableColumn<Book, String> category;

    @FXML
    private TableColumn<Book, String> status;

    String url = "jdbc:mysql://localhost:3306/librarymanagesystem?serverTimezone=UTC&characterEncoding=utf-8&useSSL=false";
    String user = "root";
    String pwd = "123456";
    String jdbc = "com.mysql.jdbc.Driver";
    ResultSet rst = null;
    Connection cont = null;
    Statement ppst = null;

    private Stage oldStage;
    public void setOldStage(Stage stage,String BookerID) {
        bookid.setCellValueFactory(new PropertyValueFactory<Book, String>("bookID"));
        title.setCellValueFactory(new PropertyValueFactory<Book, String>("Title"));
        author.setCellValueFactory(new PropertyValueFactory<Book, String>("Author"));
        publisher.setCellValueFactory(new PropertyValueFactory<Book, String>("Publisher"));
        category.setCellValueFactory(new PropertyValueFactory<Book, String>("Category"));
        status.setCellValueFactory(new PropertyValueFactory<Book, String>("Status"));
        data(booktable,bookid,title,author,publisher,category,status);
        this.BookerID=BookerID;
        oldStage = stage;
    }
    public void data(TableView booktable, TableColumn bookid, TableColumn title, TableColumn author, TableColumn publisher, TableColumn category, TableColumn status){
        try {
            Class.forName(jdbc);
        }catch(ClassNotFoundException e) {
            e.printStackTrace();
        }
        //String sql = "select * from book";
        String sql = "SELECT * FROM book order by CONVERT(Title USING gbk ) COLLATE gbk_chinese_ci ASC";
        //select id, name from user    order by CONVERT(Title USING gbk ) COLLATE gbk_chinese_ci ASC


        ObservableList<Book> data = FXCollections.observableArrayList();
        try {
            cont = DriverManager.getConnection(url, user, pwd);
            ppst = cont.createStatement();
            rst = ppst.executeQuery(sql);
            while(rst.next()) {
                data.add(new Book(rst.getString(1),rst.getString(2),rst.getString(3),rst.getString(4),rst.getString(5),rst.getString(6)));
                booktable.setItems(data);
            }
        }catch(Exception e) {
            e.printStackTrace();
        }finally {
            if(cont != null && ppst != null && rst != null) {
                try {
                    cont.close();
                    ppst.close();
                    rst.close();
                }catch(Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }


    public void onBack(ActionEvent actionEvent) throws IOException {
        Stage stage = new Stage();
        Scene scene = new Scene(new BookerMain(stage,BookerID));
        stage.setScene(scene);
        stage.setTitle("图书管理员界面");
        stage.show();
        oldStage.close();
    }


}

