package LibraryManageSystem.controller;

import LibraryManageSystem.mapper.BookMapper;
import LibraryManageSystem.mapper.ReaderMapper;
import LibraryManageSystem.pojo.Book;
import LibraryManageSystem.pojo.Reader;
import LibraryManageSystem.stage.bookadministrator.BookerMain;
import LibraryManageSystem.stage.readers.ReaderMain;
import LibraryManageSystem.utils.MybatisUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import org.apache.ibatis.session.SqlSession;

import java.io.IOException;

public class AddBookController {

    @FXML
    private ImageView coverimage;

    @FXML
    private Button chooseimage;

    @FXML
    private Button sure;

    @FXML
    private TextField author;

    @FXML
    private TextField publisher;

    @FXML
    private Button back;

    @FXML
    private TextField title;

    @FXML
    private TextField category;

    @FXML
    private TextField bookid;

    @FXML
    private TextField status;
    private Stage oldStage;
private String BookerID="";
    public void setOldStage(Stage stage, String BookerID) {// 建立舞台
        oldStage = stage;
        this.BookerID=BookerID;
    }

    public void onBack(ActionEvent actionEvent) throws IOException {
        Stage stage = new Stage();
        Scene scene = new Scene(new BookerMain(stage,BookerID));
        stage.setScene(scene);
        stage.setTitle("图书管理员界面");
        stage.show();
        oldStage.close();
    }

    public void onSure(ActionEvent actionEvent) throws IOException {
        MybatisUtils mybatisUtils=new MybatisUtils();
        SqlSession sqlSession = mybatisUtils.getSqlSession();
        BookMapper bookMapper = sqlSession.getMapper(BookMapper.class);
        Book book = new Book();
        if (!(bookid.getText().toString().equals(7))){
            Alert warning = new Alert(Alert.AlertType.WARNING, "输入图书编号不符合规范！");
            warning.setTitle("图书编号违规");
            warning.show();
        }
        else if(bookid.getText().toString().equals("")
                ||title.getText().toString().equals("")
                ||author.getText().toString().equals("")
                ||publisher.getText().toString().equals("")
                ||category.getText().toString().equals("")
                ||status.getText().toString().equals("")){
            Alert warning = new Alert(Alert.AlertType.WARNING, "输入为空！");
            warning.setTitle("违规");
            warning.show();
        }
        else{
            book.setBookID(bookid.getText().toString());
            book.setTitle(title.getText().toString());
            book.setAuthor(author.getText().toString());
            book.setPublisher(publisher.getText().toString());
            book.setCategory(category.getText().toString());
            book.setStatus(status.getText().toString());
            book.setCoverImage(null);
            System.out.println();
            bookMapper.addBook(book);
            sqlSession.close();
            Stage stage = new Stage();
            Scene scene = new Scene(new BookerMain(stage,BookerID));
            stage.setScene(scene);
            stage.setTitle("图书管理员界面");
            stage.show();
            oldStage.close();
        }

    }
}

