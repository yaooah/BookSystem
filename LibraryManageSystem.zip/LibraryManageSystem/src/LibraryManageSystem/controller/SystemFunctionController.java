package LibraryManageSystem.controller;

import LibraryManageSystem.mapper.LibrarianMapper;
import LibraryManageSystem.pojo.Librarian;
import LibraryManageSystem.stage.Login;
import LibraryManageSystem.stage.systemadministrator.AddBooker;
import LibraryManageSystem.stage.systemadministrator.ChangeBooker;
import LibraryManageSystem.utils.EncryptionUtils;
import LibraryManageSystem.utils.MybatisUtils;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import org.apache.ibatis.session.SqlSession;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SystemFunctionController {
    @FXML
    private TableView<Librarian> tableview;
    @FXML
    private Button add;

    @FXML
    private Button search;

    @FXML
    private Menu exit;

    @FXML
    private TableColumn<Librarian, String> password;

    @FXML
    private TableColumn<Librarian, String> adminname;

    @FXML
    private TextField bookerinformation;

    @FXML
    private TableColumn<Librarian, String> adminid;

    @FXML
    private TableColumn<Librarian, String> phonenumber;

    @FXML
    private Button update;

    @FXML
    private Button delete;

    private Stage oldStage;

    public void setOldStage(Stage stage) {
        MybatisUtils mybatisUtils = new MybatisUtils();
        SqlSession sqlSession = mybatisUtils.getSqlSession();
        LibrarianMapper librarianMapper = sqlSession.getMapper(LibrarianMapper.class);
        List<Librarian> librarians = librarianMapper.getAllLibrarians();

        for (Librarian librarian : librarians) {
            librarian.setPassword(EncryptionUtils.decrypt(librarian.getPassword()));
        }

        tableview.setItems(FXCollections.observableArrayList(librarians));
        adminid.setCellValueFactory(new PropertyValueFactory<>("adminID"));
        password.setCellValueFactory(new PropertyValueFactory<>("password"));
        phonenumber.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
        adminname.setCellValueFactory(new PropertyValueFactory<>("adminName"));

        sqlSession.close();
        oldStage = stage;
    }

    public void onExit(ActionEvent actionEvent) throws IOException {
        Stage stage = new Stage();
        Scene scene = new Scene(new Login(stage));
        stage.setScene(scene);
        stage.setTitle("图书借阅管理系统");
        stage.show();
        oldStage.close();
    }

    public void onAdd(ActionEvent actionEvent) throws IOException {
        Stage stage = new Stage();
        Scene scene =new Scene(new AddBooker(stage, "", "", "", ""));
        stage.setScene(scene);
        stage.setTitle("添加图书管理员信息");
        stage.show();
        oldStage.close();
    }

    @FXML
    void onDelete(ActionEvent event) {
        Librarian selectedLibrarian = tableview.getSelectionModel().getSelectedItem();
        if (selectedLibrarian != null) {
            String adminID = selectedLibrarian.getAdminID();
            MybatisUtils mybatisUtils = new MybatisUtils();
            SqlSession sqlSession = mybatisUtils.getSqlSession();
            LibrarianMapper librarianMapper = sqlSession.getMapper(LibrarianMapper.class);
            librarianMapper.deleteLibrarian(adminID);
            sqlSession.commit();
            sqlSession.close();
            tableview.getItems().remove(selectedLibrarian);
        }
    }

    @FXML
    void onSearch(ActionEvent event) {
        String searchText = bookerinformation.getText();

        MybatisUtils mybatisUtils = new MybatisUtils();
        SqlSession sqlSession = mybatisUtils.getSqlSession();
        LibrarianMapper librarianMapper = sqlSession.getMapper(LibrarianMapper.class);
        List<Librarian> librarians = librarianMapper.getAllLibrarians();

        List<Librarian> searchedLibrarians = new ArrayList<>();

        for (Librarian librarian : librarians) {
            if (librarian.getAdminID().contains(searchText) ||
                    EncryptionUtils.decrypt(librarian.getPassword()).contains(searchText) ||
                    librarian.getPhoneNumber().contains(searchText) ||
                    librarian.getAdminName().contains(searchText)) {
                searchedLibrarians.add(librarian);
            }
        }

        for (Librarian librarian : searchedLibrarians) {
            librarian.setPassword(EncryptionUtils.decrypt(librarian.getPassword()));
        }

        tableview.setItems(FXCollections.observableArrayList(searchedLibrarians));

        sqlSession.close();
    }
    @FXML
    void onUpdate(ActionEvent event) throws IOException {
        Librarian selectedLibrarian = tableview.getSelectionModel().getSelectedItem();
        if (selectedLibrarian != null) {
            String adminID = selectedLibrarian.getAdminID();
            String password = selectedLibrarian.getPassword();
            String phoneNumber = selectedLibrarian.getPhoneNumber();
            String adminName = selectedLibrarian.getAdminName();

            Stage stage = new Stage();
            Scene scene =new Scene(new ChangeBooker(stage, adminID, password, phoneNumber, adminName));
            stage.setScene(scene);
            stage.setTitle("修改图书管理员信息");
            stage.show();
            oldStage.close();
        }
    }


}
