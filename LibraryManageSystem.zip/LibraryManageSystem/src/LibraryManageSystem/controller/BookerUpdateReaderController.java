package LibraryManageSystem.controller;

import LibraryManageSystem.mapper.BookMapper;
import LibraryManageSystem.mapper.ReaderMapper;
import LibraryManageSystem.pojo.Book;
import LibraryManageSystem.pojo.Reader;
import LibraryManageSystem.stage.bookadministrator.BookerManageReader;
import LibraryManageSystem.utils.EncryptionUtils;
import LibraryManageSystem.utils.MybatisUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.apache.ibatis.session.SqlSession;

import java.io.IOException;

 public class BookerUpdateReaderController {

    @FXML
    private TextField password;

    @FXML
    private Button sure;

    @FXML
    private TextField name;

    @FXML
    private TextField phonenumber;

    @FXML
    private Button back;

    @FXML
    private TextField id;

    @FXML
    private Button borrowinformation;

    private Stage oldStage;
    private String readerId;
private String BookerID;
    public void setOldStage(Stage stage,String BookerID) {// 建立舞台
        this.BookerID=BookerID;
        MybatisUtils mybatisUtils=new MybatisUtils();
        SqlSession sqlSession = mybatisUtils.getSqlSession();
        ReaderMapper readerMapper = sqlSession.getMapper(ReaderMapper.class);
        Reader reader = readerMapper.getReaderByID(readerId);
        id.setText(reader.getReaderID().toString());
        password.setText(EncryptionUtils.decrypt(reader.getPassword().toString()));
        name.setText(reader.getReaderName().toString());
        phonenumber.setText(reader.getPhoneNumber().toString());
        sqlSession.close();

        oldStage = stage;
    }

    public void setReaderId(String readerId) {
        this.readerId = readerId;
    }

    public void onSure(ActionEvent actionEvent) throws IOException {
        MybatisUtils mybatisUtils = new MybatisUtils();
        SqlSession sqlSession = mybatisUtils.getSqlSession();
        ReaderMapper readerMapper = sqlSession.getMapper(ReaderMapper.class);
        if(!id.getText().toString().equals(8)){
            Alert warning = new Alert(Alert.AlertType.WARNING, "输入工号不符合规范！");
            warning.setTitle("工号违规");
            warning.show();
        }
        else if(id.getText().toString().equals(null)
                ||password.getText().toString().equals(null)
                ||phonenumber.getText().toString().equals(null)
                ||name.getText().toString().equals(null)){
            Alert warning = new Alert(Alert.AlertType.WARNING, "输入为空！");
            warning.setTitle("违规");
            warning.show();
        }
        else if(!(id.getText().toString().contains("S"))||!(id.getText().toString().contains("T"))){
            Alert warning = new Alert(Alert.AlertType.WARNING, "输入工号不包含S或T！");
            warning.setTitle("工号违规");
            warning.show();
        }
        else{
            Reader reader = new Reader();
            reader.setReaderID(id.getText().toString());
            reader.setPassword(EncryptionUtils.encrypt(password.getText().toString()));
            reader.setReaderName(name.getText().toString());
            reader.setPhoneNumber(phonenumber.getText().toString());
            if (id.getText().toString().contains("S")) {
                reader.setReaderType("学生");
            } else if (id.getText().toString().contains("T")) {
                reader.setReaderType("教师");
            }

            readerMapper.updateReader(reader);
            sqlSession.commit(); // 提交事务
            sqlSession.close();

            Stage stage = new Stage();
            Scene scene = new Scene(new BookerManageReader(stage,BookerID));
            stage.setScene(scene);
            stage.setTitle("查询读者个人信息");
            stage.show();
            oldStage.close();
        }

    }

    public void onBack(ActionEvent actionEvent) throws IOException {
        Stage stage = new Stage();
        Scene scene = new Scene(new BookerManageReader(stage,BookerID));
        stage.setScene(scene);
        stage.setTitle("查询读者个人信息");
        stage.show();
        oldStage.close();
    }
}

