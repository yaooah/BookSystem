package LibraryManageSystem.controller;

import LibraryManageSystem.mapper.BookMapper;
import LibraryManageSystem.pojo.Book;
import LibraryManageSystem.stage.readers.ReaderMain;
import LibraryManageSystem.utils.MybatisUtils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import org.apache.ibatis.session.SqlSession;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ReaderLookBookStatusController {
    private String ReaderID="";
    @FXML
    private Button search;

    @FXML
    private TableColumn<Book, String> author;

    @FXML
    private Button back;

    @FXML
    private TableColumn<Book, String> publisher;

    @FXML
    private TableView<Book> booktable;

    @FXML
    private TableColumn<Book, String> title;

    @FXML
    private TableColumn<Book, String> category;

    @FXML
    private TextField bookstatus;

    @FXML
    private TableColumn<Book, String> bookid;

    @FXML
    private TableColumn<Book, String> status;

    String url = "jdbc:mysql://localhost:3306/librarymanagesystem?useSSL=false&serverTimezone=UTC&characterEncoding=utf-8";
    String user = "root";
    String pwd = "123456";
    String jdbc = "com.mysql.jdbc.Driver";
    ResultSet rst = null;
    Connection cont = null;
    Statement ppst = null;

    private Stage oldStage;
    public void setOldStage(Stage stage,String ReaderID) {
        MybatisUtils mybatisUtils = new MybatisUtils();
        SqlSession sqlSession = mybatisUtils.getSqlSession();
        BookMapper bookMapper = sqlSession.getMapper(BookMapper.class);
        List<Book> books = bookMapper.getAllBooks();
        for (Book book:books){
            //System.out.println(book);
        }
        booktable.setItems(FXCollections.observableArrayList(books));
        bookid.setCellValueFactory(new PropertyValueFactory<Book, String>("bookID"));
        title.setCellValueFactory(new PropertyValueFactory<Book, String>("Title"));
        author.setCellValueFactory(new PropertyValueFactory<Book, String>("Author"));
        publisher.setCellValueFactory(new PropertyValueFactory<Book, String>("Publisher"));
        category.setCellValueFactory(new PropertyValueFactory<Book, String>("Category"));
        status.setCellValueFactory(new PropertyValueFactory<Book, String>("Status"));
        sqlSession.close();
        this.ReaderID=ReaderID;
        oldStage = stage;
    }
    public void onBack(ActionEvent actionEvent) throws IOException {
        Stage stage = new Stage();
        Scene scene = new Scene(new ReaderMain(stage,ReaderID));
        stage.setScene(scene);
        stage.setTitle("读者界面");
        stage.show();
        oldStage.close();
    }

    public void onSearch(ActionEvent actionEvent) throws IOException{
        MybatisUtils mybatisUtils = new MybatisUtils();
        SqlSession sqlSession = mybatisUtils.getSqlSession();
        BookMapper bookMapper = sqlSession.getMapper(BookMapper.class);
        List<Book> books = bookMapper.getAllBooks();
        List<Book> searchbooks = new ArrayList<>();
        for (Book book:books){
            if (book.getBookID().contains(bookstatus.getText().toString()) ||
                    book.getTitle().contains(bookstatus.getText().toString()) ||
                    book.getAuthor().contains(bookstatus.getText().toString()) ||
                    book.getPublisher().contains(bookstatus.getText().toString())||
                    book.getCategory().contains(bookstatus.getText().toString())||
                    book.getStatus().contains(bookstatus.getText().toString())) {
                searchbooks.add(book);
            }
        }
        booktable.setItems(FXCollections.observableArrayList(searchbooks));
        sqlSession.close();
    }

}
