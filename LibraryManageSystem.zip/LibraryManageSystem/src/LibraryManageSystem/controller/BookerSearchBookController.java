package LibraryManageSystem.controller;

import LibraryManageSystem.mapper.BookMapper;
import LibraryManageSystem.pojo.Book;
import LibraryManageSystem.stage.bookadministrator.AddBook;
import LibraryManageSystem.stage.bookadministrator.AddReader;
import LibraryManageSystem.stage.bookadministrator.BookerMain;
import LibraryManageSystem.stage.bookadministrator.UpdateBook;
import LibraryManageSystem.stage.readers.ReaderMain;
import LibraryManageSystem.utils.MybatisUtils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import org.apache.ibatis.session.SqlSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class BookerSearchBookController {
private String BookerID="";
    @FXML
    private Button add;

    @FXML
    private TableColumn<Book, String> author;

    @FXML
    private Button update;

    @FXML
    private Button back;

    @FXML
    private TableView<Book> booktable;

    @FXML
    private TextField check;

    @FXML
    private TableColumn<Book, String> title;

    @FXML
    private Button delete;

    @FXML
    private TableColumn<Book, String> bookid;

    @FXML
    private Button search;

    @FXML
    private TableColumn<Book, String> publisher;

    @FXML
    private TableColumn<Book, String> category;

    @FXML
    private TableColumn<Book, String> status;

    String url = "jdbc:mysql://localhost:3306/librarymanagesystem?serverTimezone=UTC&characterEncoding=utf-8&useSSL=false";
    String user = "root";
    String pwd = "123456";
    String jdbc = "com.mysql.jdbc.Driver";
    ResultSet rst = null;
    Connection cont = null;
    Statement ppst = null;

    private Stage oldStage;
    public void setOldStage(Stage stage,String BookerID) {
        bookid.setCellValueFactory(new PropertyValueFactory<Book, String>("bookID"));
        title.setCellValueFactory(new PropertyValueFactory<Book, String>("Title"));
        author.setCellValueFactory(new PropertyValueFactory<Book, String>("Author"));
        publisher.setCellValueFactory(new PropertyValueFactory<Book, String>("Publisher"));
        category.setCellValueFactory(new PropertyValueFactory<Book, String>("Category"));
        status.setCellValueFactory(new PropertyValueFactory<Book, String>("Status"));
        data(booktable,bookid,title,author,publisher,category,status);
        oldStage = stage;
    }
    public void data(TableView booktable, TableColumn bookid, TableColumn title, TableColumn author, TableColumn publisher, TableColumn category, TableColumn status){
        try {
            Class.forName(jdbc);
        }catch(ClassNotFoundException e) {
            e.printStackTrace();
        }
        String sql = "select * from book";
        ObservableList<Book> data = FXCollections.observableArrayList();
        try {
            cont = DriverManager.getConnection(url, user, pwd);
            ppst = cont.createStatement();
            rst = ppst.executeQuery(sql);
            while(rst.next()) {
                data.add(new Book(rst.getString(1),rst.getString(2),rst.getString(3),rst.getString(4),rst.getString(5),rst.getString(6)));
                booktable.setItems(data);
            }
        }catch(Exception e) {
            e.printStackTrace();
        }finally {
            if(cont != null && ppst != null && rst != null) {
                try {
                    cont.close();
                    ppst.close();
                    rst.close();
                }catch(Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
    public void onSearch(ActionEvent actionEvent) throws IOException{
        bookid.setCellValueFactory(new PropertyValueFactory<Book, String>("bookID"));
        title.setCellValueFactory(new PropertyValueFactory<Book, String>("Title"));
        author.setCellValueFactory(new PropertyValueFactory<Book, String>("Author"));
        publisher.setCellValueFactory(new PropertyValueFactory<Book, String>("Publisher"));
        category.setCellValueFactory(new PropertyValueFactory<Book, String>("Category"));
        status.setCellValueFactory(new PropertyValueFactory<Book, String>("Status"));
        updatedata(booktable,bookid,title,author,publisher,category,status);
    }
    public void updatedata(TableView booktable,TableColumn bookid,TableColumn title,TableColumn author,TableColumn publisher,TableColumn category,TableColumn status){
        try {
            Class.forName(jdbc);
        }catch(ClassNotFoundException e) {
            e.printStackTrace();
        }
        String sql = "select * from book where Title='"+check.getText().toString()+"'";
        ObservableList<Book> data = FXCollections.observableArrayList();
        try {
            cont = DriverManager.getConnection(url, user, pwd);
            ppst = cont.createStatement();
            rst = ppst.executeQuery(sql);
            while(rst.next()) {
                data.add(new Book(rst.getString(1),rst.getString(2),rst.getString(3),rst.getString(4),rst.getString(5),rst.getString(6)));
                //System.out.println(data);
                booktable.setItems(data);
            }
        }catch(Exception e) {
            e.printStackTrace();
        }finally {
            if(cont != null && ppst != null && rst != null) {
                try {
                    cont.close();
                    ppst.close();
                    rst.close();
                }catch(Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
    public void onBack(ActionEvent actionEvent) throws IOException {
        Stage stage = new Stage();
        Scene scene = new Scene(new BookerMain(stage,BookerID));
        stage.setScene(scene);
        stage.setTitle("图书管理员界面");
        stage.show();
        oldStage.close();
    }

    public void onAdd(ActionEvent actionEvent) throws IOException {
        Stage stage = new Stage();
        Scene scene = new Scene(new AddBook(stage,BookerID));
        stage.setScene(scene);
        stage.setTitle("录入图书");
        stage.show();
        oldStage.close();
    }

    public void onUpdate(ActionEvent actionEvent) throws IOException {
        if(booktable.getSelectionModel().getSelectedItem()!=null){
            String bookId = booktable.getSelectionModel().getSelectedItem().getBookID().toString();
            Stage stage = new Stage();
            Scene scene = new Scene(new UpdateBook(stage,bookId,BookerID));
            stage.setScene(scene);
            stage.setTitle("修改图书");
            stage.show();
            oldStage.close();
        }
    }
    public void onDelete(ActionEvent actionEvent) {
        if(booktable.getSelectionModel().getSelectedItem()!=null){
            String bookId = booktable.getSelectionModel().getSelectedItem().getBookID().toString();
            MybatisUtils mybatisUtils=new MybatisUtils();
            SqlSession sqlSession = mybatisUtils.getSqlSession();
            BookMapper bookMapper = sqlSession.getMapper(BookMapper.class);
            bookMapper.deleteBook(bookId);
            sqlSession.close();
        }
        data(booktable,bookid,title,author,publisher,category,status);
    }
}

