package LibraryManageSystem.controller;

import LibraryManageSystem.pojo.Book;
import LibraryManageSystem.pojo.BorrowRecord;
import LibraryManageSystem.stage.readers.ReaderMain;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ReaderLookBorrowController {
    private String ReaderID="";
    @FXML
    private TableColumn<BorrowRecord, String> recordid;

    @FXML
    private Button search;

    @FXML
    private TableView<?> borrowtable;

    @FXML
    private TableColumn<BorrowRecord, String> money;

    @FXML
    private TableColumn<BorrowRecord, String> returndate;

    @FXML
    private TableColumn<BorrowRecord, String> borrowdate;

    @FXML
    private Button back;

    @FXML
    private TableColumn<BorrowRecord, String> days;

    @FXML
    private TableColumn<BorrowRecord, String> readerid;

    @FXML
    private TextField bookstatus;

    @FXML
    private TableColumn<BorrowRecord, String> bookid;

    @FXML
    private TableColumn<BorrowRecord, String> status;
    String url = "jdbc:mysql://localhost:3306/librarymanagesystem?useSSL=false&serverTimezone=UTC&characterEncoding=utf-8";
    String user = "root";
    String pwd = "123456";
    String jdbc = "com.mysql.jdbc.Driver";
    ResultSet rst = null;
    Connection cont = null;
    Statement ppst = null;
    private Stage oldStage;
    public void setOldStage(Stage stage,String ReaderID) {
        recordid.setCellValueFactory(new PropertyValueFactory<BorrowRecord, String>("RecordID"));
        readerid.setCellValueFactory(new PropertyValueFactory<BorrowRecord, String>("ReaderID"));
        bookid.setCellValueFactory(new PropertyValueFactory<BorrowRecord, String>("BookID"));
        borrowdate.setCellValueFactory(new PropertyValueFactory<BorrowRecord, String>("BorrowDate"));
        returndate.setCellValueFactory(new PropertyValueFactory<BorrowRecord, String>("ReturnDate"));
        status.setCellValueFactory(new PropertyValueFactory<BorrowRecord, String>("BorrowStatus"));
        money.setCellValueFactory(new PropertyValueFactory<BorrowRecord, String>("FineAmount"));
        days.setCellValueFactory(new PropertyValueFactory<BorrowRecord, String>("BorrowDays"));
        data(borrowtable,recordid,readerid,bookid,borrowdate,returndate,status,money,days);
        this.ReaderID=ReaderID;
        oldStage = stage;
    }
    public void data(TableView borrowtable, TableColumn recordid, TableColumn readerid, TableColumn bookid, TableColumn borrowdate, TableColumn returndate, TableColumn status,TableColumn money,TableColumn days){
        try {
            Class.forName(jdbc);
        }catch(ClassNotFoundException e) {
            e.printStackTrace();
        }
        String sql = "select RecordID,ReaderID,BookID,BorrowDate,ReturnDate,BorrowStatus,FineAmount,BorrowDays from borrowrecord where ReaderID = 'S0000002'";
        ObservableList<BorrowRecord> data = FXCollections.observableArrayList();
        try {
            cont = DriverManager.getConnection(url, user, pwd);
            ppst = cont.createStatement();
            rst = ppst.executeQuery(sql);
            while(rst.next()) {
                data.add(new BorrowRecord(rst.getString(1),rst.getString(2),rst.getString(3),rst.getDate(4),rst.getDate(5),rst.getString(6),rst.getBigDecimal(7),rst.getInt(8)));
                //System.out.println(data);
                borrowtable.setItems(data);
            }
        }catch(Exception e) {
            e.printStackTrace();
        }finally {
            if(cont != null && ppst != null && rst != null) {
                try {
                    cont.close();
                    ppst.close();
                    rst.close();
                }catch(Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
    public void onBack(ActionEvent actionEvent) throws IOException {
        Stage stage = new Stage();
        Scene scene = new Scene(new ReaderMain(stage,ReaderID));
        stage.setScene(scene);
        stage.setTitle("读者界面");
        stage.show();
        oldStage.close();
    }

    public void onSearch(ActionEvent actionEvent) throws IOException{
        recordid.setCellValueFactory(new PropertyValueFactory<BorrowRecord, String>("RecordID"));
        readerid.setCellValueFactory(new PropertyValueFactory<BorrowRecord, String>("ReaderID"));
        bookid.setCellValueFactory(new PropertyValueFactory<BorrowRecord, String>("BookID"));
        borrowdate.setCellValueFactory(new PropertyValueFactory<BorrowRecord, String>("BorrowDate"));
        returndate.setCellValueFactory(new PropertyValueFactory<BorrowRecord, String>("ReturnDate"));
        status.setCellValueFactory(new PropertyValueFactory<BorrowRecord, String>("BorrowStatus"));
        money.setCellValueFactory(new PropertyValueFactory<BorrowRecord, String>("FineAmount"));
        days.setCellValueFactory(new PropertyValueFactory<BorrowRecord, String>("BorrowDays"));
        updatedata(borrowtable,recordid,readerid,bookid,borrowdate,returndate,status,money,days);
    }
    public void updatedata(TableView borrowtable, TableColumn recordid, TableColumn readerid, TableColumn bookid, TableColumn borrowdate, TableColumn returndate, TableColumn status,TableColumn money,TableColumn days){
        try {
            Class.forName(jdbc);
        }catch(ClassNotFoundException e) {
            e.printStackTrace();
        }
        String sql = "select RecordID,ReaderID,BookID,BorrowDate,ReturnDate,BorrowStatus,FineAmount,BorrowDays from borrowrecord where ReaderID = 'S0000002' and BorrowStatus='"+bookstatus.getText().toString()+"'";
        ObservableList<BorrowRecord> data = FXCollections.observableArrayList();
        try {
            cont = DriverManager.getConnection(url, user, pwd);
            ppst = cont.createStatement();
            rst = ppst.executeQuery(sql);
            while(rst.next()) {
                data.add(new BorrowRecord(rst.getString(1),rst.getString(2),rst.getString(3),rst.getDate(4),rst.getDate(5),rst.getString(6),rst.getBigDecimal(7),rst.getInt(8)));
                //System.out.println(data);
                borrowtable.setItems(data);
            }
        }catch(Exception e) {
            e.printStackTrace();
        }finally {
            if(cont != null && ppst != null && rst != null) {
                try {
                    cont.close();
                    ppst.close();
                    rst.close();
                }catch(Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

