package LibraryManageSystem.controller;
import LibraryManageSystem.stage.Login;
import LibraryManageSystem.stage.readers.ReaderInformation;
import LibraryManageSystem.stage.readers.ReaderLookBookStatus;
import LibraryManageSystem.stage.readers.ReaderLookBorrow;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javafx.stage.Stage;


import java.io.IOException;

public class ReaderMainController {
private String ReaderID="";
    @FXML
    private Menu exit;

    @FXML
    private Label adminname;

    @FXML
    private Menu selfborrowrecord;

    @FXML
    private Menu book;

    @FXML
    private Menu information;

    @FXML
    private MenuItem bookinformation;
    @FXML
    private MenuItem exitlogin;
    @FXML
    private MenuItem bookstatus;
    private Stage oldStage;
    @FXML
    void onExit(ActionEvent event) throws IOException {
        Stage stage = new Stage();
        Scene scene = new Scene(new Login(stage));
        stage.setScene(scene);
        stage.setTitle("图书借阅管理系统");
        stage.show();
        oldStage.close();
    }
    public void setOldStage(Stage stage,String ReaderID) {// 建立舞台
        oldStage = stage;
        this.ReaderID=ReaderID;
    }

    public void onSelfborrow(ActionEvent actionEvent) throws IOException {
        Stage stage = new Stage();
        Scene scene = new Scene(new ReaderLookBorrow(stage,ReaderID));
        stage.setScene(scene);
        stage.setTitle("查看本人借阅信息");
        stage.show();
        oldStage.close();
    }

    public void onBookInformation(ActionEvent actionEvent) throws IOException {
        Stage stage = new Stage();
        Scene scene = new Scene(new ReaderLookBookStatus(stage,ReaderID));
        stage.setScene(scene);
        stage.setTitle("查看图书信息和状态");
        stage.show();
        oldStage.close();
    }

    public void onSelfInformation(ActionEvent actionEvent) throws IOException {
        Stage stage = new Stage();
        Scene scene = new Scene(new ReaderInformation(stage,ReaderID));
        stage.setScene(scene);
        stage.setTitle("个人信息查看与修改");
        stage.show();
        oldStage.close();
    }
}

