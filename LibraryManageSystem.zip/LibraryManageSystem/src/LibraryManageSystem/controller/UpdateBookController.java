package LibraryManageSystem.controller;

import LibraryManageSystem.mapper.BookMapper;
import LibraryManageSystem.mapper.ReaderMapper;
import LibraryManageSystem.pojo.Book;
import LibraryManageSystem.pojo.Reader;
import LibraryManageSystem.stage.bookadministrator.BookerMain;

import LibraryManageSystem.stage.bookadministrator.BookerSearchBook;
import LibraryManageSystem.stage.readers.ReaderMain;
import LibraryManageSystem.utils.MybatisUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import org.apache.ibatis.session.SqlSession;

import java.io.IOException;

public class UpdateBookController {

    @FXML
    private ImageView coverimage;

    @FXML
    private Button chooseimage;

    @FXML
    private Button sure;

    @FXML
    private TextField author;

    @FXML
    private TextField publisher;

    @FXML
    private Button back;

    @FXML
    private TextField title;

    @FXML
    private TextField category;

    @FXML
    private TextField bookid;

    @FXML
    private TextField status;
    private Stage oldStage;
    private String bookId;
private String BookerID="";
    public void setOldStage(Stage stage,String BookerID) {// 建立舞台
        MybatisUtils mybatisUtils=new MybatisUtils();
        SqlSession sqlSession = mybatisUtils.getSqlSession();
        BookMapper bookMapper = sqlSession.getMapper(BookMapper.class);
        Book book = bookMapper.getBookById(bookId);
        bookid.setText(book.getBookID().toString());
        title.setText(book.getTitle().toString());
        author.setText(book.getAuthor().toString());
        publisher.setText(book.getPublisher().toString());
        category.setText(book.getCategory().toString());
        status.setText(book.getStatus().toString());
        sqlSession.close();
this.BookerID=BookerID;
        oldStage = stage;
    }

    public void onBack(ActionEvent actionEvent) throws IOException {
        Stage stage = new Stage();
        Scene scene = new Scene(new BookerMain(stage,BookerID));
        stage.setScene(scene);
        stage.setTitle("图书管理员界面");
        stage.show();
        oldStage.close();
    }

    public void onSure(ActionEvent actionEvent) throws IOException {
        MybatisUtils mybatisUtils=new MybatisUtils();
        SqlSession sqlSession = mybatisUtils.getSqlSession();
        BookMapper bookMapper = sqlSession.getMapper(BookMapper.class);
        Book book = new Book();
        book.setBookID(bookid.getText().toString());
        book.setTitle(title.getText().toString());
        book.setAuthor(author.getText().toString());
        book.setPublisher(publisher.getText().toString());
        book.setCategory(category.getText().toString());
        book.setStatus(status.getText().toString());
        book.setCoverImage(null);
        //System.out.println();
        bookMapper.updateBook(book);
        sqlSession.close();
        Stage stage = new Stage();
        Scene scene = new Scene(new BookerSearchBook(stage,BookerID));
        stage.setScene(scene);
        stage.setTitle("查询图书");
        stage.show();
        oldStage.close();
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }
}
