package LibraryManageSystem.controller;

import LibraryManageSystem.mapper.LibrarianMapper;
import LibraryManageSystem.mapper.ReaderMapper;
import LibraryManageSystem.pojo.Librarian;
import LibraryManageSystem.pojo.Reader;
import LibraryManageSystem.stage.bookadministrator.BookerMain;
import LibraryManageSystem.stage.readers.ReaderMain;
import LibraryManageSystem.utils.EncryptionUtils;
import LibraryManageSystem.utils.MybatisUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.apache.ibatis.session.SqlSession;

import java.io.IOException;

public class BookerInformationController {
private String BookerID="";
    @FXML
    private TextField password;

    @FXML
    private Button sure;

    @FXML
    private TextField phonenumber;

    @FXML
    private TextField name;

    @FXML
    private Label adminid;

    @FXML
    private Button back;

    private Stage oldStage;

    public void setOldStage(Stage stage, String BookerID) {
        MybatisUtils mybatisUtils=new MybatisUtils();
        SqlSession sqlSession = mybatisUtils.getSqlSession();
        LibrarianMapper librarianMapper = sqlSession.getMapper(LibrarianMapper.class);
        Librarian librarian = librarianMapper.getLibrarian(BookerID);
        adminid.setText(BookerID);
        password.setText(EncryptionUtils.decrypt(librarian.getPassword()));
        name.setText(librarian.getAdminName());
        phonenumber.setText(librarian.getPhoneNumber());
        sqlSession.close();
        this.BookerID=BookerID;
        oldStage = stage;

    }

    public void onSure(ActionEvent actionEvent) throws IOException{
        MybatisUtils mybatisUtils=new MybatisUtils();
        SqlSession sqlSession = mybatisUtils.getSqlSession();
        LibrarianMapper librarianMapper = sqlSession.getMapper(LibrarianMapper.class);
        Librarian librarian = new Librarian();
        if(password.getText().toString().equals("")
                ||phonenumber.getText().toString().equals("")
                ||name.getText().toString().equals("")){
            Alert warning = new Alert(Alert.AlertType.WARNING, "输入为空！");
            warning.setTitle("违规");
            warning.show();
        }
        else{
            librarian.setAdminID(BookerID);
            librarian.setPassword(EncryptionUtils.encrypt(password.getText().toString()));
            librarian.setAdminName(name.getText().toString());
            librarian.setPhoneNumber(phonenumber.getText().toString());
            librarianMapper.updateLibrarian(librarian);
            sqlSession.close();
            Stage stage = new Stage();
            Scene scene = new Scene(new BookerMain(stage,BookerID));
            stage.setScene(scene);
            stage.setTitle("图书管理员界面");
            stage.show();
            oldStage.close();
        }

    }
    public void onBack(ActionEvent actionEvent) throws IOException {
        Stage stage = new Stage();
        Scene scene = new Scene(new BookerMain(stage,BookerID));
        stage.setScene(scene);
        stage.setTitle("图书管理员界面");
        stage.show();
        oldStage.close();
    }
}

