package LibraryManageSystem.controller;

import LibraryManageSystem.mapper.LibrarianMapper;
import LibraryManageSystem.mapper.ReaderMapper;
import LibraryManageSystem.mapper.SystemAdminMapper;
import LibraryManageSystem.pojo.Librarian;
import LibraryManageSystem.pojo.Reader;
import LibraryManageSystem.pojo.SystemAdmin;
import LibraryManageSystem.stage.bookadministrator.BookerMain;
import LibraryManageSystem.stage.readers.ReaderMain;
import LibraryManageSystem.stage.systemadministrator.SystemFunciton;
import LibraryManageSystem.utils.EncryptionUtils;
import LibraryManageSystem.utils.MybatisUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import org.apache.ibatis.session.SqlSession;

import java.io.IOException;

public class LoginController {
    private Stage oldStage;

    @FXML
    private TextField ID;
    private String id = "";
    @FXML
    private PasswordField Password;
    private String pwd = "";
    @FXML
    private RadioButton Booker;

    @FXML
    private RadioButton SystemManager;

    @FXML
    private RadioButton Reader;

    public void initialize() {
        ToggleGroup toggleGroup = new ToggleGroup();
        SystemManager.setToggleGroup(toggleGroup);
        Booker.setToggleGroup(toggleGroup);
        Reader.setToggleGroup(toggleGroup);
    }

    public void setOldStage(Stage stage) {// 建立舞台
        oldStage = stage;
    }

    public void LoginAction(ActionEvent actionEvent) throws IOException {
        id = ID.getText().toString();
        pwd = Password.getText().toString();
        MybatisUtils mybatisUtils = new MybatisUtils();
        SqlSession sqlSession = mybatisUtils.getSqlSession();
        //非空且选中，连接数据库
        if (!id.equals("") && !pwd.equals("") && (SystemManager.isSelected() || Booker.isSelected() || Reader.isSelected())) {
            if (SystemManager.isSelected()) {
                SystemAdminMapper systemAdminMapper = sqlSession.getMapper(SystemAdminMapper.class);
                SystemAdmin admin = systemAdminMapper.findAdminById(id);
//                查不到数据或为空，账号不存在
                if (admin == null || admin.getAdminID() == null || admin.getPassword() == null || admin.getAdminID().equals("") || admin.getPassword().equals("")) {
                    Alert warning = new Alert(Alert.AlertType.WARNING, "管理员账号不存在！");
                    warning.setTitle("账号不存在");
                    warning.show();
                }
                //能查到数据
                else {
//                    密码错误
                    if (!pwd.equals(EncryptionUtils.decrypt(admin.getPassword()))) {
                        Alert warning = new Alert(Alert.AlertType.WARNING, "请检查密码输入是否有误");
                        warning.setTitle("密码错误");
                        warning.show();
                    } else {
                        Stage sysStage = new Stage();
                        SystemFunciton sysyem = new SystemFunciton(sysStage);
                        Scene scene = new Scene(sysyem);
                        sysStage.setTitle("系统管理员");
                        sysStage.setScene(scene);
                        sysStage.show();
                        oldStage.hide();
                        sqlSession.close();

                    }
                }

            }
            if (Booker.isSelected()) {
                LibrarianMapper librarianMapper = sqlSession.getMapper(LibrarianMapper.class);
                Librarian librarian = librarianMapper.getLibrarian(id);
//                查不到数据或为空，账号不存在
                if (librarian == null || librarian.getAdminID() == null || librarian.getPassword() == null || librarian.getAdminID().equals("") || librarian.getPassword().equals("")) {
                    Alert warning = new Alert(Alert.AlertType.WARNING, "管理员账号不存在！");
                    warning.setTitle("账号不存在");
                    warning.show();
                }
                //能查到数据
                else {
//                    密码错误
                    if (!pwd.equals(EncryptionUtils.decrypt(librarian.getPassword()))) {
                        Alert warning = new Alert(Alert.AlertType.WARNING, "请检查密码输入是否有误");
                        warning.setTitle("密码错误");
                        warning.show();
                    } else {
                        Stage bookerStage = new Stage();
                        BookerMain bookerMain = new BookerMain(bookerStage, id);
                        Scene scene = new Scene(bookerMain);
                        bookerStage.setTitle("图书管理员");
                        bookerStage.setScene(scene);
                        bookerStage.show();
                        oldStage.hide();
                        sqlSession.close();

                    }
                }
            }
            if (Reader.isSelected()) {
                ReaderMapper readerMapper = sqlSession.getMapper(ReaderMapper.class);
                Reader reader = readerMapper.getReaderByID(id);
//                查不到数据或为空，账号不存在
                if (reader == null || reader.getReaderID() == null || reader.getPassword() == null || reader.getReaderID().equals("") || reader.getPassword().equals("")) {
                    Alert warning = new Alert(Alert.AlertType.WARNING, "用户账号不存在！");
                    warning.setTitle("账号不存在");
                    warning.show();
                }
                //能查到数据
                else {
//                    密码错误
                    if (!pwd.equals(EncryptionUtils.decrypt(reader.getPassword()))) {
                        Alert warning = new Alert(Alert.AlertType.WARNING, "请检查密码输入是否有误");
                        warning.setTitle("密码错误");
                        warning.show();
                    } else {
                        Stage readerStage = new Stage();
                        ReaderMain readerMain = new ReaderMain(readerStage, id);
                        Scene scene = new Scene(readerMain);
                        readerStage.setTitle("读者");
                        readerStage.setScene(scene);
                        readerStage.show();
                        oldStage.hide();
                        sqlSession.close();

                    }
                }
            }


        } else {
            Alert warning = new Alert(Alert.AlertType.WARNING, "请输入完整的登录信息！");
            warning.setTitle("输入不完整");
            warning.show();
        }
    }
}
