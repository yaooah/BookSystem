package LibraryManageSystem.controller;

import LibraryManageSystem.mapper.LibrarianMapper;
import LibraryManageSystem.pojo.Librarian;
import LibraryManageSystem.stage.bookadministrator.BookerMain;
import LibraryManageSystem.stage.systemadministrator.SystemFunciton;
import LibraryManageSystem.utils.EncryptionUtils;
import LibraryManageSystem.utils.MybatisUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.apache.ibatis.session.SqlSession;


import java.io.IOException;

public class AddBookerController {

    @FXML
    private TextField password;

    @FXML
    private TextField adminname;

    @FXML
    private Button sure;

    @FXML
    private TextField adminid;

    @FXML
    private TextField phonenumber;

    @FXML
    private Button back;

    private Stage oldStage;
//    private String BookerID="";

    public void setOldStage(Stage stage,String AdminID,String Password,String PhoneNumber,String AdminName) {// 建立舞台
        oldStage = stage;
        adminid.setText(AdminID);
        adminname.setText(AdminName);
        password.setText(Password);
        phonenumber.setText(PhoneNumber);
//        this.BookerID=BookerID;
    }

    public void onBack(ActionEvent actionEvent) throws IOException {
        Stage stage = new Stage();
        Scene scene = new Scene(new SystemFunciton(stage));
        stage.setScene(scene);
        stage.setTitle("系统管理员界面");
        stage.show();
        oldStage.close();
    }
    @FXML
    void onSure(ActionEvent event) throws IOException {
        MybatisUtils mybatisUtils = new MybatisUtils();
        SqlSession sqlSession = mybatisUtils.getSqlSession();
        LibrarianMapper librarianMapper = sqlSession.getMapper(LibrarianMapper.class);
        Librarian librarian=new Librarian();
       if(adminid.getText().toString().length()!=5||
                adminid.getText().toString().equals("")
                ||password.getText().toString().equals("")
                ||phonenumber.getText().toString().equals("")
                ||adminname.getText().toString().equals("")){
            Alert warning = new Alert(Alert.AlertType.WARNING, "数据输入格式错误！");
            warning.setTitle("格式不规范");
            warning.show();
        }
        else{
            librarian.setAdminID(adminid.getText().toString());
            librarian.setPassword(EncryptionUtils.encrypt(password.getText().toString()));
            librarian.setPhoneNumber(phonenumber.getText().toString());
            librarian.setAdminName(adminname.getText().toString());
            librarianMapper.addLibrarian(librarian);
            sqlSession.close();
            Stage stage = new Stage();
            Scene scene = new Scene(new SystemFunciton(stage));
            stage.setScene(scene);
            stage.setTitle("系统管理员界面");
            stage.show();
            oldStage.close();
        }
    }
}
