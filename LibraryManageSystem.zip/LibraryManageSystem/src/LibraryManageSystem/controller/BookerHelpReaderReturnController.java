package LibraryManageSystem.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class BookerHelpReaderReturnController {

    @FXML
    private TextField number;

    @FXML
    private Button sure;

    @FXML
    private TextField found;

    @FXML
    private Button search2;

    @FXML
    private Button back;

    @FXML
    private TextField id;

    @FXML
    private Button search1;

    @FXML
    private TextField bookid;
    private Stage oldStage;

    private String BookerID="";
    public void setOldStage(Stage stage, String BookerID) {// 建立舞台
        oldStage = stage;
        this.BookerID=BookerID;
    }
}
