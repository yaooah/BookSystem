package LibraryManageSystem.controller;
import LibraryManageSystem.stage.Login;

import LibraryManageSystem.stage.bookadministrator.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;

public class BookerMainController {
private String BookerID="";
    @FXML
    private MenuItem add;

    @FXML
    private Menu classify;

    @FXML
    private MenuItem returnbook;

    @FXML
    private MenuItem borrowbook;

    @FXML
    private Menu bookinformation;

    @FXML
    private Menu help;

    @FXML
    private Menu exit;

    @FXML
    private MenuItem search;

    @FXML
    private Menu readerinformation;

    @FXML
    private MenuItem selfinformation;

    @FXML
    private MenuItem aclassify;

    @FXML
    private MenuItem exitlogin;

    @FXML
    private Menu information;

    @FXML
    private MenuItem category;

    @FXML
    private MenuItem searchreader;
    private Stage oldStage;
    public void setOldStage(Stage stage,String BookerID) {
        this.BookerID=BookerID;
        oldStage = stage;

    }

    @FXML
    void onSelfInformation(ActionEvent actionEvent) throws IOException {
        Stage stage = new Stage();
        Scene scene = new Scene(new BookerInformation(stage,BookerID));
        stage.setScene(scene);
        stage.setTitle("个人信息查看与修改");
        stage.show();
        oldStage.close();
    }

    @FXML
    void onSearchBook(ActionEvent actionEvent) throws IOException {
        Stage stage = new Stage();
        Scene scene = new Scene(new BookerSearchBook(stage,BookerID));
        stage.setScene(scene);
        stage.setTitle("查询图书");
        stage.show();
        oldStage.close();
    }

    @FXML
    void onAddBook(ActionEvent actionEvent) throws IOException {
        Stage stage = new Stage();
        Scene scene = new Scene(new AddBook(stage,BookerID));
        stage.setScene(scene);
        stage.setTitle("录入图书");
        stage.show();
        oldStage.close();
    }
    @FXML
   void onAClassify(ActionEvent actionEvent) throws IOException {
        Stage stage = new Stage();
        BookerAClassify bookerAClassify= new BookerAClassify(stage,BookerID);
        Scene scene = new Scene(bookerAClassify);
        stage.setScene(scene);
        stage.setTitle("按首字母分类");
        stage.show();
        oldStage.close();
    }
    @FXML
     void onTypeClassify(ActionEvent actionEvent) throws IOException {
        Stage stage = new Stage();
        Scene scene = new Scene(new BookerTypeClassify(stage,BookerID));
        stage.setScene(scene);
        stage.setTitle("按图书类别分类");
        stage.show();
        oldStage.close();
    }

    @FXML
    void onSearchReaderInformation(ActionEvent actionEvent) throws IOException{
        Stage stage = new Stage();
        Scene scene = new Scene(new BookerManageReader(stage,BookerID));
        stage.setScene(scene);
        stage.setTitle("查询读者个人信息");
        stage.show();
        oldStage.close();
    }

    @FXML
    void onExit(ActionEvent actionEvent) throws IOException {
        Stage stage = new Stage();
        Scene scene = new Scene(new Login(stage));
        stage.setScene(scene);
        stage.setTitle("图书管理系统");
        stage.show();
        oldStage.close();
    }

    @FXML
    void onBorrow(ActionEvent actionEvent) throws IOException {
        Stage stage = new Stage();
        Scene scene = new Scene(new BookerHelpReaderBorrow(stage,BookerID));
        stage.setScene(scene);
        stage.setTitle("借书");
        stage.show();
        oldStage.close();
    }
@FXML
   void onReturn(ActionEvent actionEvent) throws IOException {
        Stage stage = new Stage();
        Scene scene = new Scene(new BookerHelpReaderReturn(stage,BookerID));
        stage.setScene(scene);
        stage.setTitle("还书");
        stage.show();
        oldStage.close();
    }
}

