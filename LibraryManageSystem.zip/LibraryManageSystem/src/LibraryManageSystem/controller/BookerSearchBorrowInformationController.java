package LibraryManageSystem.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class BookerSearchBorrowInformationController {

    @FXML
    private Button search;

    @FXML
    private Button modifybutton;

    @FXML
    private Button addbutton;

    @FXML
    private Button deletebutton;

    @FXML
    private Button back;

    @FXML
    private TextField checkTextField;
    private Stage oldStage;
    private String BookerID="";

    public void setOldStage(Stage stage,String BookerID) {// 建立舞台
        oldStage = stage;
        this.BookerID=BookerID;
    }
}
