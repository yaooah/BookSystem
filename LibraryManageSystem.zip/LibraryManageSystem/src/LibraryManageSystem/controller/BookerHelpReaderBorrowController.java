package LibraryManageSystem.controller;

import LibraryManageSystem.mapper.BorrowRecordMapper;
import LibraryManageSystem.pojo.BorrowRecord;
import LibraryManageSystem.stage.Login;
import LibraryManageSystem.stage.bookadministrator.BookerMain;
import LibraryManageSystem.utils.MybatisUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.apache.ibatis.session.SqlSession;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class BookerHelpReaderBorrowController {
    private Stage oldStage;

    private String BookerID="";
    @FXML
    private Button sure;

    @FXML
    private Button back;

    @FXML
    private TextField id;

    @FXML
    private TextField time;

    @FXML
    private TextField booknumber;

    @FXML
    private TextField bookid;
    private String  readerID="";
    MybatisUtils mybatisUtils = new MybatisUtils();
    SqlSession sqlSession = mybatisUtils.getSqlSession();
    BorrowRecordMapper borrowRecordMapper=sqlSession.getMapper(BorrowRecordMapper.class);
    int num=0;
//    @FXML
//    void onChange(ActionEvent event) {
//        readerID=id.getText().toString();
//        num=borrowRecordMapper.getBorrowRecordCountByReaderId(readerID);
//        booknumber.setText(String.valueOf(num));
//        if((readerID.contains("S")&&num<10)||(readerID.contains("T")&&num<15)){
//
//        } else {
//            Alert warning = new Alert(Alert.AlertType.WARNING, "该读者已借书数量达到上限不可再借！");
//            warning.setTitle("借书数量超出");
//            warning.show();
//        }
//    }
//    @FXML
//    void onSure(ActionEvent event) throws ParseException, IOException {
//     readerID=id.getText().toString();
//            BorrowRecord borrowRecord =new BorrowRecord();
//            borrowRecord.setReaderID(readerID);
//            borrowRecord.setBookID(bookid.getText().toString());
//            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
//            Date date = format.parse(time.getText().toString());
//            borrowRecord.setBorrowDate(date);
//    borrowRecordMapper.insertBorrowRecord(borrowRecord);
//    sqlSession.close();
//            Alert warning = new Alert(Alert.AlertType.INFORMATION, "借书成功！");
//            warning.setTitle("借书");
//            warning.show();
//            Stage stage = new Stage();
//            Scene scene = new Scene(new BookerMain(stage,BookerID));
//            stage.setScene(scene);
//            stage.setTitle("图书管理员");
//            stage.show();
//            oldStage.close();
//
//
//    }

    @FXML
    void onBack(ActionEvent event) throws IOException {
        Stage stage = new Stage();
        Scene scene = new Scene(new BookerMain(stage,BookerID));
        stage.setScene(scene);
        stage.setTitle("图书管理员");
        stage.show();
        oldStage.close();
    }


    public void setOldStage(Stage stage, String BookerID) {// 建立舞台
        this.BookerID=BookerID;
        oldStage = stage;

    }

}
