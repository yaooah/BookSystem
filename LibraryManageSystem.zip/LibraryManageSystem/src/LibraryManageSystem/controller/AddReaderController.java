package LibraryManageSystem.controller;

import LibraryManageSystem.mapper.BookMapper;
import LibraryManageSystem.mapper.ReaderMapper;
import LibraryManageSystem.pojo.Book;
import LibraryManageSystem.pojo.Reader;
import LibraryManageSystem.stage.bookadministrator.BookerMain;

import LibraryManageSystem.stage.bookadministrator.BookerManageReader;
import LibraryManageSystem.utils.EncryptionUtils;
import LibraryManageSystem.utils.MybatisUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.apache.ibatis.session.SqlSession;

import java.io.IOException;

public class AddReaderController {
    @FXML
    private TextField password;

    @FXML
    private TextField adminname;

    @FXML
    private Button sure;

    @FXML
    private TextField adminid;

    @FXML
    private TextField phonenumber;

    @FXML
    private Button back;
    private Stage oldStage;
    private String BookerID="";

    public void setOldStage(Stage stage, String BookerID) {// 建立舞台
        oldStage = stage;
        this.BookerID=BookerID;
    }

    public void onBack(ActionEvent actionEvent) throws IOException {
        Stage stage = new Stage();
        Scene scene = new Scene(new BookerManageReader(stage,BookerID));
        stage.setScene(scene);
        stage.setTitle("查询读者个人信息");
        stage.show();
        oldStage.close();
    }

    public void onSure(ActionEvent actionEvent) throws IOException {

        MybatisUtils mybatisUtils=new MybatisUtils();
        SqlSession sqlSession = mybatisUtils.getSqlSession();
        ReaderMapper readerMapper = sqlSession.getMapper(ReaderMapper.class);
        if(!adminid.getText().toString().equals(8)){
            Alert warning = new Alert(Alert.AlertType.WARNING, "输入工号不符合规范！");
            warning.setTitle("工号违规");
            warning.show();
        }
        else if(adminid.getText().toString().equals("")
                ||password.getText().toString().equals("")
                ||phonenumber.getText().toString().equals("")
                ||adminname.getText().toString().equals("")){
            Alert warning = new Alert(Alert.AlertType.WARNING, "输入为空！");
            warning.setTitle("违规");
            warning.show();
        }
        else if(!(adminid.getText().toString().contains("S"))||!(adminid.getText().toString().contains("T"))){
            Alert warning = new Alert(Alert.AlertType.WARNING, "输入工号不包含S或T！");
            warning.setTitle("工号违规");
            warning.show();
        }
        else{
            Reader reader = new Reader();
            reader.setReaderID(adminid.getText().toString());
            reader.setPassword(EncryptionUtils.encrypt(password.getText().toString()));
            reader.setReaderName(adminname.getText().toString());
            reader.setPhoneNumber(phonenumber.getText().toString());
            if(adminid.getText().toString().contains("S")){
                reader.setReaderType("学生");
            }
            else if(adminid.getText().toString().contains("T")){
                reader.setReaderType("老师");
            }
            readerMapper.addReader(reader);
            sqlSession.close();
            Stage stage = new Stage();
            Scene scene = new Scene(new BookerManageReader(stage,BookerID));
            stage.setScene(scene);
            stage.setTitle("查询读者个人信息");
            stage.show();
            oldStage.close();
        }

    }
}

