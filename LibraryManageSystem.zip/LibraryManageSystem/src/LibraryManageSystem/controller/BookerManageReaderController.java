package LibraryManageSystem.controller;

import LibraryManageSystem.mapper.BookMapper;
import LibraryManageSystem.mapper.ReaderMapper;
import LibraryManageSystem.pojo.Book;
import LibraryManageSystem.pojo.Reader;
import LibraryManageSystem.stage.bookadministrator.*;
import LibraryManageSystem.utils.MybatisUtils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import org.apache.ibatis.session.SqlSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


public class BookerManageReaderController {
private String BookerID="";
    @FXML
    private Button add;

    @FXML
    private Button modify;

    @FXML
    private TableView<Reader> readertable;

    @FXML
    private TableColumn<Reader, String> password;

    @FXML
    private Button search;

    @FXML
    private TableColumn<Reader, String> adminname;

    @FXML
    private TableColumn<Reader, String> adminid;

    @FXML
    private TableColumn<Reader, String> phonenumber;

    @FXML
    private TableColumn<Reader, String> readertype;

    @FXML
    private Button back;

    @FXML
    private TextField check;

    @FXML
    private Button delete;

    String url = "jdbc:mysql://localhost:3306/librarymanagesystem?useSSL=false&serverTimezone=UTC&characterEncoding=utf-8";
    String user = "root";
    String pwd = "123456";
    String jdbc = "com.mysql.jdbc.Driver";
    ResultSet rst = null;
    Connection cont = null;
    Statement ppst = null;

    private Stage oldStage;

    public void setOldStage(Stage stage,String BookerID) {// 建立舞台
        adminid.setCellValueFactory(new PropertyValueFactory<Reader, String>("ReaderID"));
        password.setCellValueFactory(new PropertyValueFactory<Reader, String>("Password"));
        adminname.setCellValueFactory(new PropertyValueFactory<Reader, String>("ReaderName"));
        phonenumber.setCellValueFactory(new PropertyValueFactory<Reader, String>("PhoneNumber"));
        readertype.setCellValueFactory(new PropertyValueFactory<Reader, String>("ReaderType"));
        data(readertable,adminid,password,adminname,phonenumber,readertype);
        this.BookerID=BookerID;
        oldStage = stage;
    }
    public void data(TableView readertable, TableColumn adminid, TableColumn password, TableColumn adminname, TableColumn phonenumber, TableColumn readertype){
        try {
            Class.forName(jdbc);
        }catch(ClassNotFoundException e) {
            e.printStackTrace();
        }
        String sql = "select * from reader";
        ObservableList<Reader> data = FXCollections.observableArrayList();
        try {
            cont = DriverManager.getConnection(url, user, pwd);
            ppst = cont.createStatement();
            rst = ppst.executeQuery(sql);
            while(rst.next()) {
                data.add(new Reader(rst.getString(1),rst.getString(3),rst.getString(5),rst.getString(4),rst.getString(2)));
                //System.out.println(data);
                readertable.setItems(data);
            }
        }catch(Exception e) {
            e.printStackTrace();
        }finally {
            if(cont != null && ppst != null && rst != null) {
                try {
                    cont.close();
                    ppst.close();
                    rst.close();
                }catch(Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void onBack(ActionEvent actionEvent) throws IOException {
        Stage stage = new Stage();
        Scene scene = new Scene(new BookerMain(stage,BookerID));
        stage.setScene(scene);
        stage.setTitle("图书管理员界面");
        stage.show();
        oldStage.close();
    }

    public void onAdd(ActionEvent actionEvent) throws IOException {
        Stage stage = new Stage();
        Scene scene = new Scene(new AddReader(stage,BookerID));
        stage.setScene(scene);
        stage.setTitle("录入读者");
        stage.show();
        oldStage.close();
    }

    public void onUpdate(ActionEvent actionEvent) throws IOException {
        if(readertable.getSelectionModel().getSelectedItem()!=null){
            String readerId = readertable.getSelectionModel().getSelectedItem().getReaderID().toString();
            Stage stage = new Stage();
            Scene scene = new Scene(new BookerUpdateReader(stage,readerId,BookerID));
            stage.setScene(scene);
            stage.setTitle("修改读者");
            stage.show();
            oldStage.close();
        }
    }

    public void onDelete(ActionEvent actionEvent) {
        if(readertable.getSelectionModel().getSelectedItem()!=null){
            String readerId = readertable.getSelectionModel().getSelectedItem().getReaderID().toString();
            MybatisUtils mybatisUtils=new MybatisUtils();
            SqlSession sqlSession = mybatisUtils.getSqlSession();
            ReaderMapper readerMapper = sqlSession.getMapper(ReaderMapper.class);
            readerMapper.deleteReader(readerId);
            sqlSession.close();
        }
        data(readertable,adminid,password,adminname,phonenumber,readertype);
    }

    public void onSearch(ActionEvent actionEvent) throws IOException{
        adminid.setCellValueFactory(new PropertyValueFactory<Reader, String>("ReaderID"));
        password.setCellValueFactory(new PropertyValueFactory<Reader, String>("Password"));
        adminname.setCellValueFactory(new PropertyValueFactory<Reader, String>("ReaderName"));
        phonenumber.setCellValueFactory(new PropertyValueFactory<Reader, String>("PhoneNumber"));
        readertype.setCellValueFactory(new PropertyValueFactory<Reader, String>("ReaderType"));
        updatedata(readertable,adminid,password,adminname,phonenumber,readertype);
    }
    public void updatedata(TableView readertable, TableColumn adminid, TableColumn password, TableColumn adminname, TableColumn phonenumber, TableColumn readertype){
        try {
            Class.forName(jdbc);
        }catch(ClassNotFoundException e) {
            e.printStackTrace();
        }
        String sql = "select * from reader where ReaderType='"+check.getText().toString()+"'";
        ObservableList<Reader> data = FXCollections.observableArrayList();
        try {
            cont = DriverManager.getConnection(url, user, pwd);
            ppst = cont.createStatement();
            rst = ppst.executeQuery(sql);
            while(rst.next()) {
                data.add(new Reader(rst.getString(1),rst.getString(3),rst.getString(5),rst.getString(4),rst.getString(2)));
                System.out.println(check.getText().toString());
                readertable.setItems(data);
            }
        }catch(Exception e) {
            e.printStackTrace();
        }finally {
            if(cont != null && ppst != null && rst != null) {
                try {
                    cont.close();
                    ppst.close();
                    rst.close();
                }catch(Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }


}