package LibraryManageSystem.controller;

import LibraryManageSystem.mapper.ReaderMapper;
import LibraryManageSystem.mapper.SystemAdminMapper;
import LibraryManageSystem.pojo.Reader;
import LibraryManageSystem.pojo.SystemAdmin;
import LibraryManageSystem.stage.readers.ReaderMain;
import LibraryManageSystem.utils.EncryptionUtils;
import LibraryManageSystem.utils.MybatisUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.apache.ibatis.session.SqlSession;


import java.io.IOException;

public class ReaderInformationController {
    private String ReaderID="";
    private Stage oldStage;
    @FXML
    private TextField password;

    @FXML
    private Button sure;

    @FXML
    private Label readerid;

    @FXML
    private TextField readername;

    @FXML
    private TextField phonenumber;

    @FXML
    private Button back;


    public void setOldStage(Stage stage,String ReaderID) {
        this.ReaderID=ReaderID;
        MybatisUtils mybatisUtils=new MybatisUtils();
        SqlSession sqlSession = mybatisUtils.getSqlSession();
        ReaderMapper readerMapper = sqlSession.getMapper(ReaderMapper.class);
        Reader reader = readerMapper.getReaderByID(ReaderID);
        readerid.setText(ReaderID);
        password.setText(EncryptionUtils.decrypt(reader.getPassword().toString()));
        readername.setText(reader.getReaderName());
        phonenumber.setText(reader.getPhoneNumber());
        sqlSession.close();

        oldStage = stage;
    }

    public void onSure(ActionEvent actionEvent) throws IOException{
        MybatisUtils mybatisUtils=new MybatisUtils();
        SqlSession sqlSession = mybatisUtils.getSqlSession();
        ReaderMapper readerMapper = sqlSession.getMapper(ReaderMapper.class);
        Reader reader = new Reader();
        if(password.getText().toString().equals("")
                ||phonenumber.getText().toString().equals("")
                ||readername.getText().toString().equals("")){
            Alert warning = new Alert(Alert.AlertType.WARNING, "输入为空！");
            warning.setTitle("违规");
            warning.show();
        }
        else{
            reader.setReaderID(ReaderID);
            reader.setPassword(EncryptionUtils.encrypt(password.getText().toString()));
            reader.setReaderName(readername.getText().toString());
            reader.setPhoneNumber(phonenumber.getText().toString());
            if (readerid.getText().toString().contains("S")) {
                reader.setReaderType("学生");
            } else if (readerid.getText().toString().contains("T")) {
                reader.setReaderType("教师");
            }
            readerMapper.updateReader(reader);
            sqlSession.close();
            Stage stage = new Stage();
            Scene scene = new Scene(new ReaderMain(stage,ReaderID));
            stage.setScene(scene);
            stage.setTitle("读者界面");
            stage.show();
            oldStage.close();
        }

    }
    public void onBack(ActionEvent actionEvent) throws IOException {
        Stage stage = new Stage();
        Scene scene = new Scene(new ReaderMain(stage,ReaderID));
        stage.setScene(scene);
        stage.setTitle("读者界面");
        stage.show();
        oldStage.close();
    }
}
