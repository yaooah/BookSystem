package LibraryManageSystem.mapper;

import LibraryManageSystem.pojo.SystemAdmin;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SystemAdminMapper {

    // 根据管理员ID查询管理员信息
    SystemAdmin findAdminById(String adminID);

    // 根据手机号码查询管理员信息
    SystemAdmin findAdminByPhoneNumber(String phoneNumber);

    // 添加管理员
    int addAdmin(SystemAdmin admin);

    // 更新管理员信息
    int updateAdmin(SystemAdmin admin);

    // 删除管理员
    int deleteAdmin(String adminID);

}

