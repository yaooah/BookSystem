package LibraryManageSystem.mapper;

import LibraryManageSystem.pojo.Book;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
@Mapper
public interface BookMapper {
    List<Book> getAllBooks();
    Book getBookById(String bookID);
    void addBook(Book book);
    void updateBook(Book book);
    void deleteBook(String bookID);
}

