package LibraryManageSystem.mapper;

import LibraryManageSystem.pojo.Reader;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ReaderMapper {
    Reader getReaderByID(String readerID);

    void addReader(Reader reader);

    void updateReader(Reader reader);

    void deleteReader(String readerID);
}