package LibraryManageSystem.mapper;

import LibraryManageSystem.pojo.Librarian;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface LibrarianMapper {

    void addLibrarian(Librarian librarian);

    void updateLibrarian(Librarian librarian);

    void deleteLibrarian(String adminID);

    Librarian getLibrarian(String adminID);
    List<Librarian> getAllLibrarians();
}
