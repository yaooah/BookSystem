package LibraryManageSystem.mapper;

import LibraryManageSystem.pojo.BorrowRecord;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface BorrowRecordMapper {
    void insertBorrowRecord(BorrowRecord borrowRecord);
    List<BorrowRecord> getAllBorrowRecords(); // 添加查询所有借阅记录的方法
    void updateBorrowRecord(BorrowRecord borrowRecord);
    int getBorrowRecordCountByReaderId(String readerID);
}
