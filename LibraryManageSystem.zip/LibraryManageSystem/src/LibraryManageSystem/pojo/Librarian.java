package LibraryManageSystem.pojo;

public class Librarian {

    private String AdminID;
    private String Password;
    private String PhoneNumber;
    private String AdminName;

    public String getAdminID() {
        return AdminID;
    }

    public void setAdminID(String adminID) {
        this.AdminID = adminID;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        this.Password = password;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.PhoneNumber = phoneNumber;
    }

    public String getAdminName() {
        return AdminName;
    }

    public void setAdminName(String adminName) {
        this.AdminName = adminName;
    }


}

