package LibraryManageSystem.pojo;

import java.math.BigDecimal;
import java.util.Date;

public class BorrowRecord {
    private String RecordID;
    private String LibrarianID;
    private String ReaderID;
    private String BookID;
    private Date BorrowDate;
    private Date ReturnDate;
    private String BorrowStatus;
    private BigDecimal FineAmount;
    private Integer BorrowDays;

    public BorrowRecord() {

    }

    @Override
    public String toString() {
        String info = String.format("BorrowRecord{RecordID=%s, LibrarianID=%s, ReaderID=%s, BookID=%s, BorrowDate=%s, ReturnDate=%s, BorrowStatus=%s, FineAmount=%s, BorrowDays=%s}",
                RecordID, LibrarianID, ReaderID, BookID, BorrowDate, ReturnDate, BorrowStatus, FineAmount, BorrowDays);
        return info;
    }
    public BorrowRecord(String RecordID,String ReaderID,String BookID,Date BorrowDate,Date ReturnDate,String BorrowStatus,BigDecimal FineAmount,Integer BorrowDays){
        this.RecordID = RecordID;
        this.ReaderID = ReaderID;
        this.BookID = BookID;
        this.BorrowDate = BorrowDate;
        this.ReturnDate = ReturnDate;
        this.BorrowStatus = BorrowStatus;
        this.FineAmount = FineAmount;
        this.BorrowDays = BorrowDays;
    }
    public String getRecordID() {
        return RecordID;
    }

    public void setRecordID(String recordID) {
        this.RecordID = recordID;
    }

    public String getLibrarianID() {
        return LibrarianID;
    }

    public void setLibrarianID(String librarianID) {
        this.LibrarianID = librarianID;
    }

    public String getReaderID() {
        return ReaderID;
    }

    public void setReaderID(String readerID) {
        this.ReaderID = readerID;
    }

    public String getBookID() {
        return BookID;
    }

    public void setBookID(String bookID) {
        this.BookID = bookID;
    }

    public Date getBorrowDate() {
        return BorrowDate;
    }

    public void setBorrowDate(Date borrowDate) {
        this.BorrowDate = borrowDate;
    }

    public Date getReturnDate() {
        return ReturnDate;
    }

    public void setReturnDate(Date returnDate) {
        this.ReturnDate = returnDate;
    }

    public String getBorrowStatus() {
        return BorrowStatus;
    }

    public void setBorrowStatus(String borrowStatus) {
        this.BorrowStatus = borrowStatus;
    }

    public BigDecimal getFineAmount() {
        return FineAmount;
    }

    public void setFineAmount(BigDecimal fineAmount) {
        this.FineAmount = fineAmount;
    }

    public Integer getBorrowDays() {
        return BorrowDays;
    }

    public void setBorrowDays(Integer borrowDays) {
        this.BorrowDays = borrowDays;
    }
}


