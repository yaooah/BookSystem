package LibraryManageSystem.pojo;

import LibraryManageSystem.utils.EncryptionUtils;

public class Reader {
    private String ReaderID; // 对应数据库表中的ReaderID字段
    private String ReaderType; // 对应数据库表中的ReaderType字段
    private String Password; // 对应数据库表中的Password字段
    private String PhoneNumber; // 对应数据库表中的PhoneNumber字段
    private String ReaderName; // 对应数据库表中的ReaderName字段
    @Override
    public String toString() {
        String info = String.format("Reader{ReaderID=%s, ReaderType=%s, Password=%s, PhoneNumber=%s, ReaderName=%s}",
                ReaderID, ReaderType, ReaderID, Password, PhoneNumber, ReaderName);
        return info;
    }
    public Reader(){

    }
    public Reader(String ReaderID,String Password,String ReaderName,String PhoneNumber,String ReaderType){
        this.ReaderID = ReaderID;
        this.Password = EncryptionUtils.decrypt(Password);
        this.ReaderName = ReaderName;
        this.PhoneNumber = PhoneNumber;
        this.ReaderType = ReaderType;
    }
    // Getter和Setter方法
    public String getReaderID() {
        return ReaderID;
    }

    public void setReaderID(String readerID) {
        this.ReaderID = readerID;
    }

    public String getReaderType() {
        return ReaderType;
    }

    public void setReaderType(String readerType) {
        this.ReaderType = readerType;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        this.Password = password;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.PhoneNumber = phoneNumber;
    }

    public String getReaderName() {
        return ReaderName;
    }

    public void setReaderName(String readerName) {
        this.ReaderName = readerName;
    }
}

