package LibraryManageSystem.pojo;

import javafx.beans.property.SimpleStringProperty;

public class Book {
    private String bookID;
    private String Title;
    private String Author;
    private String Publisher;
    private String Category;
    private String Status;
    private String CoverImage;

    @Override
    public String toString() {
        String info=String.format("Book{bookID=%s,Title=%s,Author=%s,Publisher=%s,Category=%s,Status=%s}",bookID,Title,Author,Publisher,Category,Status);
        return info;
    }
    public Book(){}
    public Book(String bookID, String Title, String Author, String Publisher, String Category, String Status){
        this.bookID = new String(bookID);
        this.Title = new String(Title);
        this.Author = new String(Author);
        this.Publisher = new String(Publisher);
        this.Category = new String(Category);
        this.Status = new String(Status);
    }
    public String getBookID() {
        return bookID;
    }

    public void setBookID(String bookID) {
        this.bookID = bookID;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        this.Title = title;
    }

    public String getAuthor() {
        return Author;
    }

    public void setAuthor(String author) {
        this.Author = author;
    }

    public String getPublisher() {
        return Publisher;
    }

    public void setPublisher(String publisher) {
        this.Publisher = publisher;
    }

    public String getCategory() {
        return Category;
    }

    public void setCategory(String category) {
        this.Category = category;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        this.Status = status;
    }

    public String getCoverImage() {
        return CoverImage;
    }

    public void setCoverImage(String coverImage) {
        this.CoverImage = coverImage;
    }


}

