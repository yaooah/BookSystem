package LibraryManageSystem;


import LibraryManageSystem.mapper.SystemAdminMapper;
import LibraryManageSystem.pojo.SystemAdmin;
import LibraryManageSystem.stage.Login;
import LibraryManageSystem.utils.EncryptionUtils;
import LibraryManageSystem.utils.MybatisUtils;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import org.apache.ibatis.session.SqlSession;

import java.io.IOException;


public class Main  extends Application {


    public void start(Stage stage) throws IOException {

        Scene scene = new Scene(new Login(stage));
        stage.setScene(scene);
        stage.setTitle("登录");
        stage.show();

    }


    public static  void main(String[] args)  {
        // 设置默认编码为UTF-8
        System.setProperty("file.encoding", "UTF-8");

        // 设置JavaFX应用程序的编码为UTF-8
        System.setProperty("javafx.encoding", "UTF-8");
       launch(args);

//        MybatisUtils mybatisUtils=new MybatisUtils();
//        SqlSession sqlSession = mybatisUtils.getSqlSession();
//        SystemAdminMapper systemAdminMapper = sqlSession.getMapper(SystemAdminMapper.class);
//        SystemAdmin admin = systemAdminMapper.findAdminById("00001");
//        System.out.println(admin.getAdminName());
//        sqlSession.close();
//        String password ="123456";
//        String encryptedText = EncryptionUtils.encrypt(password);
//        System.out.println(encryptedText);
//        String dex=EncryptionUtils.decrypt("tXFqyKae5bg6DwE0k1nDTA==");
//        System.out.println(dex);



    }
}
