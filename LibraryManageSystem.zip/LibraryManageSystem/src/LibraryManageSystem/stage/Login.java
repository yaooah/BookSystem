package LibraryManageSystem.stage;

import LibraryManageSystem.controller.LoginController;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class Login extends Pane {

    public Login(Stage stage) throws IOException {
        try {
            FXMLLoader fxmlloader = new FXMLLoader(getClass().getResource("../view/login.fxml"));
            this.getChildren().add(fxmlloader.load());
            ((LoginController)fxmlloader.getController()).initialize();
            ((LoginController)fxmlloader.getController()).setOldStage(stage);


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}