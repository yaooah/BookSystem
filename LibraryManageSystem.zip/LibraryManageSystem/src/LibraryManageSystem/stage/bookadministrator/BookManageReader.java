package LibraryManageSystem.stage.bookadministrator;



import LibraryManageSystem.controller.BookerManageReaderController;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class BookManageReader extends Pane {

    public BookManageReader(Stage stage,String BookerID) throws IOException {
        try {
            FXMLLoader fxmlloader = new FXMLLoader(getClass().getResource("../../view/bookmanagereader.fxml"));
            this.getChildren().add(fxmlloader.load());
            ((BookerManageReaderController)fxmlloader.getController()).setOldStage(stage,BookerID);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}