package LibraryManageSystem.stage.bookadministrator;



import LibraryManageSystem.controller.BookerUpdateReaderController;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class BookerUpdateReader extends Pane {

    public BookerUpdateReader(Stage stage,String readerId,String BookerID) throws IOException {
        try {
            FXMLLoader fxmlloader = new FXMLLoader(getClass().getResource("../../view/bookerupdatereader.fxml"));
            this.getChildren().add(fxmlloader.load());
            ((BookerUpdateReaderController)fxmlloader.getController()).setReaderId(readerId);
            ((BookerUpdateReaderController)fxmlloader.getController()).setOldStage(stage,BookerID);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}