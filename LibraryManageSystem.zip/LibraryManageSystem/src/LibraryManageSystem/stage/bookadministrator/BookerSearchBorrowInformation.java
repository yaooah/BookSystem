package LibraryManageSystem.stage.bookadministrator;


import LibraryManageSystem.controller.BookerSearchBorrowInformationController;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class BookerSearchBorrowInformation extends Pane {

    public BookerSearchBorrowInformation(Stage stage,String BookerID) throws IOException {
        try {
            FXMLLoader fxmlloader = new FXMLLoader(getClass().getResource("../../view/bookersearchborrowinformation.fxml"));
            this.getChildren().add(fxmlloader.load());
            ((BookerSearchBorrowInformationController)fxmlloader.getController()).setOldStage(stage,BookerID);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}