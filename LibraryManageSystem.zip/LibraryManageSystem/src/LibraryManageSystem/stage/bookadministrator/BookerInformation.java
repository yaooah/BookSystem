package LibraryManageSystem.stage.bookadministrator;


import LibraryManageSystem.controller.BookerInformationController;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class BookerInformation extends Pane {

    public BookerInformation(Stage stage,String BookerID) throws IOException {
        try {
            FXMLLoader fxmlloader = new FXMLLoader(getClass().getResource("../../view/bookerinformation.fxml"));
            this.getChildren().add(fxmlloader.load());
            ((BookerInformationController)fxmlloader.getController()).setOldStage(stage,BookerID);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}