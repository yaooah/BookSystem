package LibraryManageSystem.stage.bookadministrator;


import LibraryManageSystem.controller.BookerManageReaderController;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class BookerManageReader extends Pane {

    public BookerManageReader(Stage stage,String BookerID) throws IOException {
        try {
            FXMLLoader fxmlloader = new FXMLLoader(getClass().getResource("../../view/bookermanagereader.fxml"));
            this.getChildren().add(fxmlloader.load());
            ((BookerManageReaderController)fxmlloader.getController()).setOldStage(stage,BookerID);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}