package LibraryManageSystem.stage.bookadministrator;


import LibraryManageSystem.controller.AddReaderController;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class AddReader extends Pane {

    public AddReader(Stage stage,String BookerID) throws IOException {
        try {
            FXMLLoader fxmlloader = new FXMLLoader(getClass().getResource("../../view/addreader.fxml"));
            this.getChildren().add(fxmlloader.load());
            ((AddReaderController)fxmlloader.getController()).setOldStage(stage,BookerID);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
