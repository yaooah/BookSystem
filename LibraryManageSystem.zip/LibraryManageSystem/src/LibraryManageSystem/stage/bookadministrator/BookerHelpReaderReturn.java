package LibraryManageSystem.stage.bookadministrator;


import LibraryManageSystem.controller.BookerHelpReaderReturnController;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class BookerHelpReaderReturn extends Pane {

    public BookerHelpReaderReturn(Stage stage,String BookerID) throws IOException {
        try {
            FXMLLoader fxmlloader = new FXMLLoader(getClass().getResource("../../view/bookerhelpreaderreturn.fxml"));
            this.getChildren().add(fxmlloader.load());
            ((BookerHelpReaderReturnController)fxmlloader.getController()).setOldStage(stage,BookerID);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}