package LibraryManageSystem.stage.bookadministrator;

import LibraryManageSystem.controller.AddBookController;

import LibraryManageSystem.controller.BookerMainController;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class AddBook extends Pane {

    public  AddBook(Stage stage,String BookerID) throws IOException {
        try {
            FXMLLoader fxmlloader = new FXMLLoader(getClass().getResource("../../view/addbook.fxml"));
            this.getChildren().add(fxmlloader.load());
            ((AddBookController)fxmlloader.getController()).setOldStage(stage,BookerID);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
