package LibraryManageSystem.stage.bookadministrator;


import LibraryManageSystem.controller.BookerMainController;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class BookerMain extends Pane {

    public BookerMain(Stage stage,String BookerID) throws IOException {
        try {
            FXMLLoader fxmlloader = new FXMLLoader(getClass().getResource("../../view/bookermain.fxml"));
            this.getChildren().add(fxmlloader.load());
            ((BookerMainController)fxmlloader.getController()).setOldStage(stage,BookerID);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}