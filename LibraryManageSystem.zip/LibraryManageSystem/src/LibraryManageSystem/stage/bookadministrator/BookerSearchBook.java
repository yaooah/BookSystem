package LibraryManageSystem.stage.bookadministrator;


import LibraryManageSystem.controller.BookerSearchBookController;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class BookerSearchBook extends Pane {

    public BookerSearchBook(Stage stage,String BookerID) throws IOException {
        try {
            FXMLLoader fxmlloader = new FXMLLoader(getClass().getResource("../../view/bookersearchbook.fxml"));
            this.getChildren().add(fxmlloader.load());
            ((BookerSearchBookController)fxmlloader.getController()).setOldStage(stage,BookerID);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}