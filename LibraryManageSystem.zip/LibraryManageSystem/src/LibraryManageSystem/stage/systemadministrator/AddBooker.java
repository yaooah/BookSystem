package LibraryManageSystem.stage.systemadministrator;

import LibraryManageSystem.controller.AddBookerController;

import javafx.fxml.FXMLLoader;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class AddBooker extends Pane {

    public AddBooker(Stage stage,String AdminID,String Password,String PhoneNumber,String AdminName) throws IOException {
        try {
            FXMLLoader fxmlloader = new FXMLLoader(getClass().getResource("../../view/addbooker.fxml"));
            this.getChildren().add(fxmlloader.load());
            ((AddBookerController)fxmlloader.getController()).setOldStage(stage,AdminID,Password,PhoneNumber,AdminName);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
