package LibraryManageSystem.stage.systemadministrator;

import LibraryManageSystem.controller.AddBookerController;
import LibraryManageSystem.controller.ChangeBookerController;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class ChangeBooker extends Pane {

    public ChangeBooker(Stage stage, String AdminID, String Password, String PhoneNumber, String AdminName) throws IOException {
        try {
            FXMLLoader fxmlloader = new FXMLLoader(getClass().getResource("../../view/changebooker.fxml"));
            this.getChildren().add(fxmlloader.load());
            ((ChangeBookerController)fxmlloader.getController()).setOldStage(stage,AdminID,Password,PhoneNumber,AdminName);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
