package LibraryManageSystem.stage.systemadministrator;

import LibraryManageSystem.controller.SystemFunctionController;

import javafx.fxml.FXMLLoader;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class SystemFunciton extends Pane {

    public SystemFunciton(Stage stage) throws IOException {
        try {
            FXMLLoader fxmlloader = new FXMLLoader(getClass().getResource("../../view/system.fxml"));
            this.getChildren().add(fxmlloader.load());
            ((SystemFunctionController)fxmlloader.getController()).setOldStage(stage);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
