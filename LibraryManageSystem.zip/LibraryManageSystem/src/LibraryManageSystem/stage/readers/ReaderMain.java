package LibraryManageSystem.stage.readers;

import LibraryManageSystem.controller.ReaderMainController;

import javafx.fxml.FXMLLoader;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class ReaderMain extends Pane {

    public ReaderMain(Stage stage,String ReaderID) throws IOException {
        try {
            FXMLLoader fxmlloader = new FXMLLoader(getClass().getResource("../../view/readermain.fxml"));
            this.getChildren().add(fxmlloader.load());
            ((ReaderMainController)fxmlloader.getController()).setOldStage(stage,ReaderID);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
