package LibraryManageSystem.stage.readers;


import LibraryManageSystem.controller.ReaderInformationController;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class ReaderInformation extends Pane {

    public ReaderInformation(Stage stage,String ReaderID) throws IOException {
        try {
            FXMLLoader fxmlloader = new FXMLLoader(getClass().getResource("../../view/readerinformation.fxml"));
            this.getChildren().add(fxmlloader.load());
            ((ReaderInformationController)fxmlloader.getController()).setOldStage(stage,ReaderID);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
