package LibraryManageSystem.stage.readers;


import LibraryManageSystem.controller.ReaderLookBorrowController;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class ReaderLookBorrow extends Pane {

    public ReaderLookBorrow(Stage stage,String ReaderID) throws IOException {
        try {
            FXMLLoader fxmlloader = new FXMLLoader(getClass().getResource("../../view/readerlookborrow.fxml"));
            this.getChildren().add(fxmlloader.load());
            ((ReaderLookBorrowController) fxmlloader.getController()).setOldStage(stage,ReaderID);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
