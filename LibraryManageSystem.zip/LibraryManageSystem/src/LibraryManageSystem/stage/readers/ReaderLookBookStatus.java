package LibraryManageSystem.stage.readers;


import LibraryManageSystem.controller.ReaderLookBookStatusController;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class ReaderLookBookStatus extends Pane {

    public ReaderLookBookStatus(Stage stage,String ReaderID) throws IOException {
        try {
            FXMLLoader fxmlloader = new FXMLLoader(getClass().getResource("../../view/readerlookbookstatus.fxml"));
            this.getChildren().add(fxmlloader.load());
            ((ReaderLookBookStatusController)fxmlloader.getController()).setOldStage(stage,ReaderID);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
